function tau = computed_torque_control( ...
    q, qd, q_des, qd_des, qdd_des, Kp, Kd, robot)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Computed Torque Control (Craig)
%
% v = qdd_des + Kd (qd_des - qd) + Kp (q_des - q)
% tau = RNE(q, qd, v)
%
% Inputs:
%   q, qd        : 1xN actual joint position & velocity
%   q_des        : 1xN desired joint position
%   qd_des       : 1xN desired joint velocity
%   qdd_des      : 1xN desired joint acceleration
%   Kp, Kd       : NxN gain matrices
%   robot        : robot parameter struct
%
% Output:
%   tau          : Nx1 joint torque vector
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% ---------------- Input formatting ----------------
q       = q(:);
qd      = qd(:);
q_des   = q_des(:);
qd_des  = qd_des(:);
qdd_des = qdd_des(:);

N = length(q);

%% ---------------- Input validation ----------------
assert(all(size(Kp)==[N N]), 'Kp must be NxN');
assert(all(size(Kd)==[N N]), 'Kd must be NxN');

%% ---------------- Virtual control input ----------------
v = qdd_des + Kd*(qd_des - qd) + Kp*(q_des - q);

%% ---------------- Inverse dynamics ----------------
% rne_dynamics expects row vectors
tau = rne_dynamics(q.', qd.', v.', robot);

%% ---------------- Optional torque saturation ----------------
% Set tau_max to actuator limits if available
tau_max = inf;
tau = max(min(tau, tau_max), -tau_max);

end
