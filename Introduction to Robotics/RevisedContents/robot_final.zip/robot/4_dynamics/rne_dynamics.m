function tau = rne_dynamics(q, qd, qdd, robot)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Recursive Newton–Euler Dynamics (Craig, Modified DH)
%
% Uses the SAME MDH transform as FK:
%   A_i = Rx(h_i) * Tx(a_i) * Rz(q_i) * Tz(d_i)
%
% Inputs:
%   q   : 1x6 [rad]
%   qd  : 1x6 [rad/s]
%   qdd : 1x6 [rad/s^2]
% Output:
%   tau : 6x1 [Nm]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

n = robot.n;
z = [0;0;1];

% --- helpers (3x3 rotations, 4x4 transforms) ---
Rx3 = @(x)[1 0 0;
           0 cos(x) -sin(x);
           0 sin(x)  cos(x)];
Rz3 = @(z)[cos(z) -sin(z) 0;
           sin(z)  cos(z) 0;
           0 0 1];

Rx = @(x)[Rx3(x) [0;0;0];
          0 0 0 1];
Tx = @(x)[eye(3) [x;0;0];
          0 0 0 1];
Rz = @(z)[Rz3(z) [0;0;0];
          0 0 0 1];
Tz = @(z)[eye(3) [0;0;z];
          0 0 0 1];

% --- build all A_i, extract R_i and p_i (in frame {i-1}) ---
R = zeros(3,3,n);     % R_i : rotation from {i-1} to {i}
p = zeros(3,n);       % p_i : vector from O_{i-1} to O_i expressed in {i-1}

for i = 1:n
    Ai = Rx(robot.h(i)) * Tx(robot.a(i)) * Rz(q(i)) * Tz(robot.d(i));
    R(:,:,i) = Ai(1:3,1:3);
    p(:,i)   = Ai(1:3,4);
end

% --- forward recursion (all expressed in frame {i}) ---
w  = zeros(3,n+1);
wd = zeros(3,n+1);
vd = zeros(3,n+1);

vd(:,1) = -robot.g;  % base linear acceleration in frame {0}

for i = 1:n
    Ri = R(:,:,i);

    w(:,i+1)  = Ri.' * w(:,i) + z*qd(i);
    wd(:,i+1) = Ri.' * wd(:,i) + z*qdd(i) + cross(w(:,i+1), z*qd(i));

    vd(:,i+1) = Ri.' * ( vd(:,i) + cross(wd(:,i), p(:,i)) + cross(w(:,i), cross(w(:,i), p(:,i))) );
end

% --- backward recursion (forces/moments in frame {i}) ---
f    = zeros(3,n+1);
nvec = zeros(3,n+1);
tau  = zeros(n,1);

for i = n:-1:1
    % COM acceleration in frame {i}
    rci = robot.rc(:,i);
    vcd = vd(:,i+1) + cross(wd(:,i+1), rci) + cross(w(:,i+1), cross(w(:,i+1), rci));

    Fi = robot.m(i) * vcd;
    Ni = robot.I(:,:,i)*wd(:,i+1) + cross(w(:,i+1), robot.I(:,:,i)*w(:,i+1));

    if i == n
        f(:,i)    = Fi;
        nvec(:,i) = Ni + cross(rci, Fi);
    else
        Rip1 = R(:,:,i+1);          % rotation {i} -> {i+1}
        pip1 = p(:,i+1);            % vector O_i -> O_{i+1} expressed in {i}

        f(:,i)    = Rip1 * f(:,i+1) + Fi;
        nvec(:,i) = Ni + Rip1 * nvec(:,i+1) + cross(rci, Fi) + cross(pip1, Rip1*f(:,i+1));
    end

    tau(i) = nvec(:,i).' * z;
end

end
