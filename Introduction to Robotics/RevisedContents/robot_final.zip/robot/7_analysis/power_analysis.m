function power_analysis(q, qd, tau, t)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Joint power & energy analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

P = tau .* qd;           % instantaneous power
E = trapz(t, abs(P), 2); % energy per joint

figure;
subplot(2,1,1)
plot(t,P','LineWidth',1.2);
title('Joint Power');
ylabel('Power [W]');
grid on;

subplot(2,1,2)
bar(E);
title('Energy per Joint');
ylabel('Energy [J]');
xlabel('Joint');
grid on;
end
