function singularity_analysis()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Singularity and manipulability analysis for 6-DOF robot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

robot = robot_params();

q_range = linspace(-pi, pi, 200);

manip = zeros(size(q_range));
condJ = zeros(size(q_range));

for k = 1:length(q_range)

    q = [0 0 q_range(k) 0 0 0];

    J = jacobian_numeric(q, robot);
    Jv = J(1:3,:);

    M = Jv * Jv.';
    manip(k) = sqrt(max(det(M), 0));

    condJ(k) = min(cond(Jv), 1e6);

end

figure;

subplot(2,1,1)
plot(q_range*180/pi, manip, 'LineWidth', 1.5)
xlabel('q_3 [deg]')
ylabel('Manipulability')
grid on
title('Yoshikawa Manipulability vs q_3')

subplot(2,1,2)
plot(q_range*180/pi, condJ, 'LineWidth', 1.5)
xlabel('q_3 [deg]')
ylabel('Condition number')
grid on
title('Jacobian Condition Number vs q_3')

end
