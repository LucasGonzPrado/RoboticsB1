function [T06_sym, d, t, a, h] = fk_mdh_symbolic()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Symbolic Forward Kinematics of a 6-DOF Serial Robot
% using Modified Denavit–Hartenberg (MDH, Craig) Convention
%
% - Fully symbolic formulation
% - No numeric values
% - No geometry assumptions
%
% Output:
%   T06_sym : symbolic homogeneous transform from base to end-effector
%
% T_0^6 = A_1 * A_2 * A_3 * A_4 * A_5 * A_6
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% ================= SYMBOL DEFINITIONS =================
% d_i     : offset along z_i
% t_i     : rotation about z_i (joint variables)
% a_{i-1} : distance from z_{i-1} to z_i along x_{i-1}
% h_{i-1} : twist from z_{i-1} to z_i about x_{i-1}

syms d1 d2 d3 d4 d5 d6 real
syms t1 t2 t3 t4 t5 t6 real
syms a0 a1 a2 a3 a4 a5 real
syms h0 h1 h2 h3 h4 h5 real

d = [d1 d2 d3 d4 d5 d6];
t = [t1 t2 t3 t4 t5 t6];
a = [a0 a1 a2 a3 a4 a5];
h = [h0 h1 h2 h3 h4 h5];

%% ================= MDH ELEMENTARY TRANSFORMS =================
% Modified DH (Craig):
% A_i = Rx(h_{i-1}) * Tx(a_{i-1}) * Rz(t_i) * Tz(d_i)

Rx = @(x)[1 0 0 0;
          0 cos(x) -sin(x) 0;
          0 sin(x)  cos(x) 0;
          0 0 0 1];

Tx = @(x)[1 0 0 x;
          0 1 0 0;
          0 0 1 0;
          0 0 0 1];

Rz = @(z)[cos(z) -sin(z) 0 0;
          sin(z)  cos(z) 0 0;
          0 0 1 0;
          0 0 0 1];

Tz = @(z)[1 0 0 0;
          0 1 0 0;
          0 0 1 z;
          0 0 0 1];

%% ================= INDIVIDUAL LINK TRANSFORMS =================
A = sym(zeros(4,4,6));

for i = 1:6
    A(:,:,i) = Rx(h(i)) * Tx(a(i)) * Rz(t(i)) * Tz(d(i));
end

%% ================= FORWARD KINEMATICS =================
T06_sym = eye(4,'sym');
for i = 1:6
    T06_sym = T06_sym * A(:,:,i);
end

do_simplify = true;
if do_simplify
    T06_sym = simplify(T06_sym);
end

end
