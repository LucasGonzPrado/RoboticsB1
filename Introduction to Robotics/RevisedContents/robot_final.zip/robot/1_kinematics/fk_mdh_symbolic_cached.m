function [T06_sym, d, t, a, h] = fk_mdh_symbolic_cached()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Cached symbolic FK for numeric evaluation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

syms d1 d2 d3 d4 d5 d6 real
syms t1 t2 t3 t4 t5 t6 real
syms a0 a1 a2 a3 a4 a5 real
syms h0 h1 h2 h3 h4 h5 real

d = [d1 d2 d3 d4 d5 d6];
t = [t1 t2 t3 t4 t5 t6];
a = [a0 a1 a2 a3 a4 a5];
h = [h0 h1 h2 h3 h4 h5];

Rx = @(x)[1 0 0 0;
          0 cos(x) -sin(x) 0;
          0 sin(x)  cos(x) 0;
          0 0 0 1];

Tx = @(x)[1 0 0 x;
          0 1 0 0;
          0 0 1 0;
          0 0 0 1];

Rz = @(z)[cos(z) -sin(z) 0 0;
          sin(z)  cos(z) 0 0;
          0 0 1 0;
          0 0 0 1];

Tz = @(z)[1 0 0 0;
          0 1 0 0;
          0 0 1 z;
          0 0 0 1];

T06_sym = eye(4,'sym');

for i = 1:6
    T06_sym = T06_sym * Rx(h(i)) * Tx(a(i)) * ...
                         Rz(t(i)) * Tz(d(i));
end

T06_sym = simplify(T06_sym);

end
