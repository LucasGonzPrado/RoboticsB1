function [J_sym, d, t, a, h] = jacobian_symbolic()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Symbolic Geometric Jacobian for a 6-DOF Serial Robot
% using MDH (Craig) Convention
%
% Outputs:
%   J_sym : 6x6 symbolic Jacobian [Jv; Jw]
%   d,t,a,h : symbolic MDH parameter vectors (for numeric substitution)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Symbolic variables
syms d1 d2 d3 d4 d5 d6 real
syms t1 t2 t3 t4 t5 t6 real
syms a0 a1 a2 a3 a4 a5 real
syms h0 h1 h2 h3 h4 h5 real

d = [d1 d2 d3 d4 d5 d6];
t = [t1 t2 t3 t4 t5 t6];
a = [a0 a1 a2 a3 a4 a5];
h = [h0 h1 h2 h3 h4 h5];

%% Forward kinematics
T06 = fk_mdh_symbolic();

%% Preallocate
z = sym(zeros(3,6));
p = sym(zeros(3,7));

z(:,1) = [0;0;1];
p(:,1) = [0;0;0];

T = eye(4,'sym');

%% Extract frames
for i = 1:6
    Rx = @(x)[1 0 0 0;
              0 cos(x) -sin(x) 0;
              0 sin(x)  cos(x) 0;
              0 0 0 1];
    Tx = @(x)[1 0 0 x;
              0 1 0 0;
              0 0 1 0;
              0 0 0 1];
    Rz = @(z)[cos(z) -sin(z) 0 0;
              sin(z)  cos(z) 0 0;
              0 0 1 0;
              0 0 0 1];
    Tz = @(z)[1 0 0 0;
              0 1 0 0;
              0 0 1 z;
              0 0 0 1];

    Ai = Rx(h(i)) * Tx(a(i)) * Rz(t(i)) * Tz(d(i));
    T  = T * Ai;

    z(:,i)   = T(1:3,3);
    p(:,i+1) = T(1:3,4);
end

pe = p(:,7);

%% Jacobian
Jv = sym(zeros(3,6));
Jw = sym(zeros(3,6));

for i = 1:6
    Jw(:,i) = z(:,i);
    Jv(:,i) = cross(z(:,i), pe - p(:,i));
end

J_sym = simplify([Jv; Jw]);

end
