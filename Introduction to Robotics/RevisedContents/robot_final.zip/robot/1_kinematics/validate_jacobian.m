function validate_jacobian()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Jacobian validation using finite differences
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

robot = robot_params();

% Test configuration (away from singularities)
q  = [20 -30 40 10 15 -25] * pi/180;
dq = [ 0.5 -0.3 0.4 0.2 0.1 -0.2] * pi/180;

dt = 1e-5;

% Central difference
[~,~,p_plus]  = fk_numeric(q + dq*dt, robot);
[~,~,p_minus] = fk_numeric(q - dq*dt, robot);

v_fd = (p_plus - p_minus) / (2*dt);

% Jacobian velocity
J = jacobian_numeric(q, robot);
v_jac = J(1:3,:) * dq.';

% Display comparison
disp('Finite-difference linear velocity:');
disp(v_fd);

disp('Jacobian-predicted linear velocity:');
disp(v_jac);

err = v_fd - v_jac;

disp('Velocity error:');
disp(err);

disp(['Error norm: ', num2str(norm(err))]);

end
