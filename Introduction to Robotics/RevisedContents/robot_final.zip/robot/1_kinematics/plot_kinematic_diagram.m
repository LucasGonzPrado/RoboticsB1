function plot_kinematic_diagram(robot)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot kinematic diagram with MDH frames
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

q = robot.q_home;     % home configuration
n = robot.n;

figure; hold on; axis equal; grid on;
xlabel('X'); ylabel('Y'); zlabel('Z');
title('6-DOF Robot Kinematic Diagram (MDH Frames)');

T = eye(4);
p_prev = [0;0;0];

for i = 1:n
    % MDH transform
    Rx = @(x)[1 0 0 0;
              0 cos(x) -sin(x) 0;
              0 sin(x)  cos(x) 0;
              0 0 0 1];
    Tx = @(x)[1 0 0 x;
              0 1 0 0;
              0 0 1 0;
              0 0 0 1];
    Rz = @(z)[cos(z) -sin(z) 0 0;
              sin(z)  cos(z) 0 0;
              0 0 1 0;
              0 0 0 1];
    Tz = @(z)[1 0 0 0;
              0 1 0 0;
              0 0 1 z;
              0 0 0 1];

    A = Rx(robot.h(i)) * Tx(robot.a(i)) * ...
        Rz(q(i)) * Tz(robot.d(i));

    T = T * A;
    p = T(1:3,4);

    % Plot link
    plot3([p_prev(1) p(1)], ...
          [p_prev(2) p(2)], ...
          [p_prev(3) p(3)], 'k','LineWidth',2);

    % Plot frame axes
    scale = 0.04;
    R = T(1:3,1:3);
    quiver3(p(1),p(2),p(3),scale*R(1,1),scale*R(2,1),scale*R(3,1),'r');
    quiver3(p(1),p(2),p(3),scale*R(1,2),scale*R(2,2),scale*R(3,2),'g');
    quiver3(p(1),p(2),p(3),scale*R(1,3),scale*R(2,3),scale*R(3,3),'b');

    text(p(1),p(2),p(3),sprintf(' {%d}',i));

    p_prev = p;
end

view(135,30);
legend({'Link','x_i','y_i','z_i'});
end
