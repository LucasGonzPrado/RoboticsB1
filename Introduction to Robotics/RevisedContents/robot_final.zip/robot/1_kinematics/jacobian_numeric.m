function J_num = jacobian_numeric(q, robot)

persistent J_sym d t a h

if isempty(J_sym)
    [J_sym, d, t, a, h] = jacobian_symbolic();
end

J_num = double(subs(J_sym, ...
    [d a h t], ...
    [robot.d robot.a robot.h q]));

end
