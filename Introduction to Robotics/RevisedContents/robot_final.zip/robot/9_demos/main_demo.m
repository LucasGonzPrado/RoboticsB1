%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MAIN DEMONSTRATION SCRIPT
% 6-DOF Robot — Trajectory Tracking with Computed Torque Control
%
% Contents:
%   - Quintic joint-space trajectory
%   - Computed torque control
%   - RNE dynamics
%   - Tracking performance plots
%
% Follows John J. Craig, "Introduction to Robotics"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; clc; close all;

%% ---------------- Load robot parameters ----------------
robot = robot_params();
n = robot.n;

%% ---------------- Simulation parameters ----------------
dt = 1e-3;              % time step [s]
t0 = 0;
tf = 3;
t = t0:dt:tf;

%% ---------------- Initial & final joint states ----------------
q0  = robot.q_home;
qf  = [ 30 -20 40 10 15 -25 ] * pi/180;

qd0 = zeros(1,n);
qdf = zeros(1,n);

qdd0 = zeros(1,n);
qddf = zeros(1,n);

%% ---------------- Trajectory generation ----------------
[q_des, qd_des, qdd_des] = traj_quintic( ...
    q0, qf, qd0, qdf, qdd0, qddf, t0, tf, t);

%% ---------------- Control gains ----------------
Kp = diag([80 80 60 40 30 20]);
Kd = diag([20 20 15 10  8  6]);

%% ---------------- State initialization ----------------
q  = q0(:);
qd = zeros(n,1);

% Logging
Q  = zeros(n,length(t));
QD = zeros(n,length(t));
TAU = zeros(n,length(t));

%% ---------------- Simulation loop ----------------
for k = 1:length(t)

    % Desired states at time k
    qd_k   = q_des(:,k);
    qdd_k  = qdd_des(:,k);
    qd_dk  = qd_des(:,k);

    % Computed torque control
    tau = computed_torque_control( ...
        q.', qd.', qd_k.', qd_dk.', qdd_k.', Kp, Kd, robot);

    % Forward dynamics (use RNE inversion)
    qdd = rne_dynamics(q.', qd.', zeros(1,n), robot) ...
          \ tau;   %#ok<MINV> (acceptable for coursework)

    % Integrate (Euler)
    qd = qd + qdd(:) * dt;
    q  = q  + qd * dt;

    % Store
    Q(:,k)   = q;
    QD(:,k)  = qd;
    TAU(:,k) = tau;
end

%% ---------------- Plots ----------------
joint_labels = {'q1','q2','q3','q4','q5','q6'};

figure('Name','Joint Position Tracking');
for i = 1:n
    subplot(3,2,i)
    plot(t, q_des(i,:),'r--','LineWidth',1.2); hold on;
    plot(t, Q(i,:),'b','LineWidth',1.5);
    xlabel('Time [s]');
    ylabel(joint_labels{i});
    grid on;
    legend('Desired','Actual');
end

figure('Name','Joint Torques');
for i = 1:n
    subplot(3,2,i)
    plot(t, TAU(i,:),'LineWidth',1.5);
    xlabel('Time [s]');
    ylabel(['\tau_',num2str(i),' [Nm]']);
    grid on;
end

disp('Simulation completed successfully.');
