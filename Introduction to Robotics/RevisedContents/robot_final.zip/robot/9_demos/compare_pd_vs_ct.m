function compare_pd_vs_ct()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PD vs Computed Torque tracking comparison
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

robot = robot_params();
n = robot.n;

dt = 1e-3;
t  = 0:dt:3;

q0 = robot.q_home;
qf = [30 -20 40 10 15 -25]*pi/180;

[q_des, qd_des, qdd_des] = traj_quintic( ...
    q0, qf, zeros(1,n), zeros(1,n), ...
    zeros(1,n), zeros(1,n), 0, 3, t);

Kp = diag([80 80 60 40 30 20]);
Kd = diag([20 20 15 10  8  6]);

q_pd = q0(:); qd_pd = zeros(n,1);
q_ct = q0(:); qd_ct = zeros(n,1);

Qpd = zeros(n,length(t));
Qct = zeros(n,length(t));

for k = 1:length(t)
    % --- PD control ---
    tau_pd = pd_control(q_pd.', qd_pd.', ...
        q_des(:,k).', qd_des(:,k).', Kp, Kd);

    qdd_pd = rne_dynamics(q_pd.', qd_pd.', zeros(1,n), robot) \ tau_pd;
    qd_pd = qd_pd + qdd_pd*dt;
    q_pd  = q_pd  + qd_pd*dt;

    % --- Computed torque ---
    tau_ct = computed_torque_control( ...
        q_ct.', qd_ct.', ...
        q_des(:,k).', qd_des(:,k).', qdd_des(:,k).', ...
        Kp, Kd, robot);

    qdd_ct = rne_dynamics(q_ct.', qd_ct.', zeros(1,n), robot) \ tau_ct;
    qd_ct = qd_ct + qdd_ct*dt;
    q_ct  = q_ct  + qd_ct*dt;

    Qpd(:,k) = q_pd;
    Qct(:,k) = q_ct;
end

% Plot comparison
figure;
for i = 1:n
    subplot(3,2,i)
    plot(t,q_des(i,:),'k--'); hold on;
    plot(t,Qpd(i,:),'r');
    plot(t,Qct(i,:),'b');
    title(['Joint ',num2str(i)]);
    legend('Desired','PD','Computed Torque');
    grid on;
end
end
