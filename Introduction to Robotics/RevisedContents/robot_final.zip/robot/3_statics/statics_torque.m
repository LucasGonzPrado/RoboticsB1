function tau = statics_torque(q, F, robot)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Static joint torques from end-effector wrench
%
% Inputs:
%   q     : 1x6 joint configuration [rad]
%   F     : 6x1 wrench at TCP [Fx Fy Fz Mx My Mz]'
%   robot : robot parameter struct
%
% Output:
%   tau   : 6x1 joint torque vector [Nm]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Jacobian
J = jacobian_numeric(q, robot);

% Static torque mapping
tau = J.' * F;

end
