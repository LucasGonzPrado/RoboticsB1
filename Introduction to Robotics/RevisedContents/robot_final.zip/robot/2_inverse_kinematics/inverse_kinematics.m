function Q = inverse_kinematics(T06, robot)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Hybrid analytical-numeric IK for 6R robot (Craig MDH)
% Returns verified solutions only
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Q = [];

R06 = T06(1:3,1:3);
p06 = T06(1:3,4);

%% Wrist center
pw = p06 - robot.d(6) * R06(:,3);

%% Joint 1 candidates
q1_list = atan2(pw(2), pw(1)) + [0 pi];

for q1 = q1_list

    % Geometry (approximate — seed only)
    r = hypot(pw(1), pw(2)) - robot.a(1);
    s = pw(3) - robot.d(1);

    a2 = robot.a(2);
    a3 = robot.a(3);

    D = (r^2 + s^2 - a2^2 - a3^2)/(2*a2*a3);

    if abs(D) > 1
        continue
    end

    q3_list = atan2([+sqrt(1-D^2), -sqrt(1-D^2)], D);

    for q3 = q3_list

        q2 = atan2(s,r) - atan2(a3*sin(q3), a2 + a3*cos(q3));

        % Compute R03
        T03 = fk_03_numeric([q1 q2 q3], robot);
        R03 = T03(1:3,1:3);

        R36 = R03.' * R06;

        % Wrist angles
        q5 = atan2(hypot(R36(3,1), R36(3,2)), R36(3,3));

        if abs(sin(q5)) < 1e-6
            q4 = 0;
            q6 = atan2(-R36(1,2), R36(1,1));
            q_set = [q1 q2 q3 q4 q5 q6];
        else
            q4 = atan2(R36(2,3), R36(1,3));
            q6 = atan2(R36(3,2), -R36(3,1));
            q_set = [
                q1 q2 q3 q4  q5 q6;
                q1 q2 q3 q4 -q5 q6
            ];
        end

        % FK verification
        for k = 1:size(q_set,1)
            [Tchk,~,~] = fk_numeric(q_set(k,:), robot);
            if norm(Tchk - T06,'fro') < 1e-6
                Q = [Q; q_set(k,:)];
            end
        end
    end
end

% Remove duplicates & wrap
Q = unique(round(Q,6),'rows');
Q = wrapToPi(Q);

end
