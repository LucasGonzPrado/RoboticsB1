function pw = wrist_center(T06, robot)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Computes wrist center position from end-effector pose
% pw = p06 - d6 * z6
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

R06 = T06(1:3,1:3);
p06 = T06(1:3,4);

pw = p06 - robot.d(6) * R06(:,3);

end
