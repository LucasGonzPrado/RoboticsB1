function T03 = fk_03_numeric(q, robot)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Forward kinematics from base to frame 3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Rx = @(x)[1 0 0 0;
          0 cos(x) -sin(x) 0;
          0 sin(x)  cos(x) 0;
          0 0 0 1];

Tx = @(x)[1 0 0 x;
          0 1 0 0;
          0 0 1 0;
          0 0 0 1];

Rz = @(z)[cos(z) -sin(z) 0 0;
          sin(z)  cos(z) 0 0;
          0 0 1 0;
          0 0 0 1];

Tz = @(z)[1 0 0 0;
          0 1 0 0;
          0 0 1 z;
          0 0 0 1];

T03 = eye(4,'like',q);

for i = 1:3
    A = Rx(robot.h(i)) * Tx(robot.a(i)) * ...
        Rz(q(i)) * Tz(robot.d(i));
    T03 = T03 * A;
end

end
