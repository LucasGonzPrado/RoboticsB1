function [T06_num, R06_num, p06_num] = fk_numeric(q, robot)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Numeric Forward Kinematics for a 6-DOF Robot (MDH, Craig)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

persistent T06_sym d t a h

% -------------------------------------------------------
% Load symbolic FK ONCE
% -------------------------------------------------------
if isempty(T06_sym)
    [T06_sym, d, t, a, h] = fk_mdh_symbolic_cached();
end

% -------------------------------------------------------
% Numeric substitution
% -------------------------------------------------------
T06_num = double(subs(T06_sym, ...
    [d a h t], ...
    [robot.d robot.a robot.h q]));

% -------------------------------------------------------
% Split rotation and position
% -------------------------------------------------------
R06_num = T06_num(1:3,1:3);
p06_num = T06_num(1:3);

% -------------------------------------------------------
% Orthogonality check
% -------------------------------------------------------
orth_error = R06_num * R06_num.' - eye(3);
if norm(orth_error,'fro') > 1e-9
    warning('Rotation matrix is not orthonormal!');
end

end
