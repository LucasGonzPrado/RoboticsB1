function tau_g = statics_gravity(q, robot)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Gravity compensation torques using COM Jacobians
% (Craig, Chapter 6)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tau_g = zeros(6,1);
g = robot.g;

for i = 1:robot.n

    % --- Forward kinematics up to link i ---
    T = eye(4);
    z = zeros(3,i);
    p = zeros(3,i+1);

    z(:,1) = [0;0;1];
    p(:,1) = [0;0;0];

    for j = 1:i
        Rx = @(x)[1 0 0;
                  0 cos(x) -sin(x);
                  0 sin(x)  cos(x)];
        Rz = @(z)[cos(z) -sin(z) 0;
                  sin(z)  cos(z) 0;
                  0 0 1];

        Rj = Rx(robot.h(j)) * Rz(q(j));
        pj = [robot.a(j); 0; robot.d(j)];

        T(1:3,1:3) = T(1:3,1:3) * Rj;
        T(1:3,4)   = T(1:3,4) + T(1:3,1:3)*pj;

        if j < i
            z(:,j+1) = T(1:3,3);
        end
        p(:,j+1) = T(1:3,4);
    end

    % --- COM position ---
    p_com = p(:,i+1) + T(1:3,1:3)*robot.rc(:,i);

    % --- COM Jacobian ---
    Jv = zeros(3,6);
    for j = 1:i
        Jv(:,j) = cross(z(:,j), p_com - p(:,j));
    end

    % --- Gravity force ---
    Fi = robot.m(i) * g;

    % --- Accumulate torque ---
    tau_g = tau_g + Jv.' * Fi;
end

end
