function tau = pd_control(q, qd, q_des, qd_des, Kp, Kd)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Joint-Space PD Control (Craig)
%
% τ = Kp (q_des - q) + Kd (qd_des - qd)
%
% Inputs:
%   q      : 1xN actual joint positions
%   qd     : 1xN actual joint velocities
%   q_des  : 1xN desired joint positions
%   qd_des : 1xN desired joint velocities
%   Kp     : NxN proportional gain matrix
%   Kd     : NxN derivative gain matrix
%
% Output:
%   tau    : Nx1 joint torque vector
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% ---------------- Input formatting ----------------
q      = q(:);
qd     = qd(:);
q_des  = q_des(:);
qd_des = qd_des(:);

N = length(q);

%% ---------------- Input validation ----------------
assert(all(size(Kp)==[N N]), 'Kp must be an NxN matrix');
assert(all(size(Kd)==[N N]), 'Kd must be an NxN matrix');

%% ---------------- PD control law ----------------
tau = Kp*(q_des - q) + Kd*(qd_des - qd);

%% ---------------- Optional torque saturation ----------------
% Set tau_max to numeric limits if needed (e.g., actuator limits)
tau_max = inf;
tau = max(min(tau, tau_max), -tau_max);

end
