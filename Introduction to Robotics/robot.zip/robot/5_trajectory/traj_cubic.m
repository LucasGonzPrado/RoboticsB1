function [q, qd, qdd] = traj_cubic(q0, qf, qd0, qdf, t0, tf, t)
function [q, qd, qdd] = traj_cubic(q0, qf, qd0, qdf, t0, tf, t)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Cubic Joint-Space Trajectory Generation (Craig)
%
% q(t) = a0 + a1 t + a2 t^2 + a3 t^3
%
% Boundary conditions:
%   q(t0)  = q0
%   q(tf)  = qf
%   qd(t0) = qd0
%   qd(tf) = qdf
%
% Inputs:
%   q0   : 1xN initial joint position
%   qf   : 1xN final joint position
%   qd0  : 1xN initial joint velocity
%   qdf  : 1xN final joint velocity
%   t0   : initial time
%   tf   : final time
%   t    : time vector
%
% Outputs:
%   q    : Nxlength(t) joint positions
%   qd   : Nxlength(t) joint velocities
%   qdd  : Nxlength(t) joint accelerations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% ---------------- Input validation ----------------
assert(length(q0)==length(qf),  'q0 and qf must have same size');
assert(length(q0)==length(qd0),'q0 and qd0 must have same size');
assert(length(q0)==length(qdf),'q0 and qdf must have same size');
assert(tf > t0, 'Final time tf must be greater than t0');

%% ---------------- Time handling ----------------
t = t(:).';           % ensure row vector
T = tf - t0;          % duration
tau = t - t0;         % shifted time

% Clamp time to [t0, tf]
tau(t < t0) = 0;
tau(t > tf) = T;

%% ---------------- Preallocate ----------------
N = length(q0);
q   = zeros(N, length(t));
qd  = zeros(N, length(t));
qdd = zeros(N, length(t));

%% ---------------- Trajectory coefficients ----------------
for i = 1:N
    % Cubic coefficients (Craig)
    a0 = q0(i);
    a1 = qd0(i);
    a2 = (3*(qf(i)-q0(i))/T^2) - (2*qd0(i)+qdf(i))/T;
    a3 = (-2*(qf(i)-q0(i))/T^3) + (qd0(i)+qdf(i))/T^2;

    % Position
    q(i,:) = a0 + a1*tau + a2*tau.^2 + a3*tau.^3;

    % Velocity
    qd(i,:) = a1 + 2*a2*tau + 3*a3*tau.^2;

    % Acceleration
    qdd(i,:) = 2*a2 + 6*a3*tau;
end

end
