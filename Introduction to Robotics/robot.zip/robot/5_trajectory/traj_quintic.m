function [q, qd, qdd] = traj_quintic(q0, qf, qd0, qdf, qdd0, qddf, t0, tf, t)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Quintic Joint-Space Trajectory Generation (Craig)
%
% q(t) = a0 + a1 t + a2 t^2 + a3 t^3 + a4 t^4 + a5 t^5
%
% Boundary conditions:
%   q(t0)   = q0     , q(tf)   = qf
%   qd(t0)  = qd0    , qd(tf)  = qdf
%   qdd(t0) = qdd0   , qdd(tf) = qddf
%
% Inputs:
%   q0, qf    : 1xN joint positions
%   qd0, qdf  : 1xN joint velocities
%   qdd0,qddf : 1xN joint accelerations
%   t0, tf    : initial and final time
%   t         : time vector
%
% Outputs:
%   q, qd, qdd : Nxlength(t) position, velocity, acceleration
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% ---------------- Input validation ----------------
assert(length(q0)==length(qf),   'q0 and qf size mismatch');
assert(length(q0)==length(qd0),  'q0 and qd0 size mismatch');
assert(length(q0)==length(qdf),  'q0 and qdf size mismatch');
assert(length(q0)==length(qdd0), 'q0 and qdd0 size mismatch');
assert(length(q0)==length(qddf), 'q0 and qddf size mismatch');
assert(tf > t0, 'Final time tf must be greater than t0');

%% ---------------- Time handling ----------------
t = t(:).';          % ensure row vector
T = tf - t0;         % duration
tau = t - t0;        % shifted time

% Clamp time to [t0, tf]
tau(t < t0) = 0;
tau(t > tf) = T;

%% ---------------- Preallocate ----------------
N   = length(q0);
q   = zeros(N, length(t));
qd  = zeros(N, length(t));
qdd = zeros(N, length(t));

%% ---------------- Quintic coefficients & trajectory ----------------
for i = 1:N
    % Quintic coefficients (Craig)
    a0 = q0(i);
    a1 = qd0(i);
    a2 = qdd0(i)/2;

    a3 = ( 20*(qf(i)-q0(i)) ...
         - (8*qdf(i)+12*qd0(i))*T ...
         - (3*qdd0(i)-qddf(i))*T^2 ) / (2*T^3);

    a4 = ( 30*(q0(i)-qf(i)) ...
         + (14*qdf(i)+16*qd0(i))*T ...
         + (3*qdd0(i)-2*qddf(i))*T^2 ) / (2*T^4);

    a5 = ( 12*(qf(i)-q0(i)) ...
         - (6*qdf(i)+6*qd0(i))*T ...
         - (qdd0(i)-qddf(i))*T^2 ) / (2*T^5);

    % Position
    q(i,:) = a0 + a1*tau + a2*tau.^2 + ...
             a3*tau.^3 + a4*tau.^4 + a5*tau.^5;

    % Velocity
    qd(i,:) = a1 + 2*a2*tau + ...
              3*a3*tau.^2 + 4*a4*tau.^3 + 5*a5*tau.^4;

    % Acceleration
    qdd(i,:) = 2*a2 + ...
               6*a3*tau + 12*a4*tau.^2 + 20*a5*tau.^3;
end

end
