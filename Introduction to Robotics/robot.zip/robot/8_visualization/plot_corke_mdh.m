function plot_corke_mdh(robot, q)

if nargin < 2
    q = robot.q_home;
end

a = robot.a;
d = robot.d;
alpha = robot.h;

for i = 1:robot.n
    L(i) = Link('d', d(i), 'a', a(i), 'alpha', alpha(i), 'modified');
end

R = SerialLink(L, 'name', '6DOF-MDHTEST');

% TCP offset
R.tool = transl(0,0,0.12539);

figure;
R.plot(q, ...
    'workspace', [-0.4 0.4 -0.4 0.4 -0.2 0.6], ...
    'scale', 0.5);

title('Peter Corke MDH Plot');
end
