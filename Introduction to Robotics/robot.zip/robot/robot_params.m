function robot = robot_params()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Robot Parameters for 6-DOF Serial Manipulator
% Craig-style Modified Denavit–Hartenberg (MDH)
%
% Geometry extracted from SolidWorks CAD model (home configuration)
% Mass & inertia extracted from SolidWorks mass properties
%
% This file contains ONLY robot-specific data.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% ---------------- General ----------------
robot.n = 6;
robot.g = [0; 0; -9.81];     % gravity in base frame [m/s^2]

%% ---------------- MDH Parameters (Craig) ----------------
% A_i = Rx(h_{i-1}) * Tx(a_{i-1}) * Rz(t_i) * Tz(d_i)
%
% d_i     : offset along z_i
% a_{i-1} : distance along x_{i-1}
% h_{i-1} : twist about x_{i-1}

% Distances from CAD (meters)
robot.h = [ ...
    0.0,    -pi/2, 0.0,    -pi/2,    +pi/2,    -pi/2];
robot.a = [ ...
    0.0,    0.0,   105.96, 146.52,   0.0,      0.0]     * 1e-3;
robot.d = [ ...
    160.99, 0.0,   0.0,    137.21,   0.0,        0.0]     * 1e-3;


%% ---------------- Joint Limits ----------------
robot.q_min = [-pi  -pi/2 -pi  -pi  -pi  -pi];
robot.q_max = [ pi   pi/2  pi   pi   pi   pi ];

%% ---------------- Dynamics Parameters (from SolidWorks) ----------------
% Units converted to SI:
% mass: g -> kg
% COM : mm -> m
% inertia at COM: g*mm^2 -> kg*m^2

robot.m = [ ...
    0.48260, ... % J1J2
    0.16932, ... % J2J3
    0.09966, ... % J3J4
    0.08765, ... % J4J5
    0.07652, ... % J5J6
    0.06713  ... % J6 / tool link
];

% Center of mass of each link in its own frame (meters)
robot.rc = [ ...
     0.03504,  0.04933,  0.00918, -0.00003,  0.01586,  0.00003;
     0.00023,  0.03834,  0.00000,  0.00004,  0.00005, -0.00030;
     0.03933, -0.01501,  0.00606,  0.03223,  0.00000,  0.00015
];

% Inertia tensors about COM, aligned with link frames (kg*m^2)
robot.I = zeros(3,3,robot.n);

robot.I(:,:,1) = 1e-9 * [ ...
    1082235.72,    8017.18,  947551.40;
       8017.18, 2042498.74,    8210.69;
     947551.40,    8210.69, 1114029.01 ];

robot.I(:,:,2) = 1e-9 * [ ...
     209412.58,  211956.78,    3277.54;
     211956.78,  252818.62,    2924.32;
       3277.54,    2924.32,  457442.38 ];

robot.I(:,:,3) = 1e-9 * [ ...
      12688.29,      -0.03,   -1591.21;
         -0.03,   41525.37,      -0.08;
      -1591.21,      -0.08,   41304.58 ];

robot.I(:,:,4) = 1e-9 * [ ...
     106132.61,     -40.36,     -37.25;
        -40.36,  120949.37,      50.14;
        -37.25,      50.14,   30748.17 ];

robot.I(:,:,5) = 1e-9 * [ ...
       9424.79,       1.25,       0.94;
          1.25,   24518.72,       0.00;
          0.94,       0.00,   24323.68 ];

robot.I(:,:,6) = 1e-9 * [ ...
       8591.32,      -0.01,       0.67;
         -0.01,    8591.32,      -0.89;
          0.67,      -0.89,   12814.36 ];

%% ---------------- Home Configuration ----------------
robot.q_home = [0, -pi/2, pi/2, pi/2, pi/2, pi/2]*pi/180;
end
