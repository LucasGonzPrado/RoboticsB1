function [q, success, info] = ikineMDH(MDH, q0, T_target, maxIter)
% IKINEMDH  Numerical inverse kinematics (damped least squares) for MDH robot.
%
%   [q, success, info] = ikineMDH(MDH, q0, T_target, maxIter)
%
%   Inputs:
%     MDH      : n x 5 MDH table
%     q0       : n x 1 initial guess
%     T_target : 4 x 4 desired end-effector pose
%     maxIter  : (optional) max iterations (default 200)
%
%   Outputs:
%     q        : n x 1 IK solution (if success = true, within tolerance)
%     success  : true/false
%     info     : struct with fields iter, errNorm

    if nargin < 4, maxIter = 200; end

    n = size(MDH,1);
    q = q0(:);

    if numel(q) ~= n
        error('q0 length must match number of joints.');
    end
    if ~isequal(size(T_target), [4 4])
        error('T_target must be 4x4.');
    end

    % Parameters
    lambda = 1e-2;    % damping
    wR     = 0.5;     % orientation weight (rad relative to meters)
    tol    = 1e-4;

    success = false;
    info = struct('iter', 0, 'errNorm', inf);

    for k = 1:maxIter
        [~, T_all] = fkineMDH_all(MDH, q);
        T = T_all(:,:,end);

        % Position error
        e_p = T_target(1:3,4) - T(1:3,4);

        % Orientation error: rotation taking current -> target
        R_err = T_target(1:3,1:3) * T(1:3,1:3)';
        [axis, ang] = rotm2axang_local(R_err);
        e_o = axis * ang;

        % Weighted error
        e = [e_p; wR*e_o];
        errNorm = norm(e);

        info.iter = k;
        info.errNorm = errNorm;

        if errNorm < tol
            success = true;
            return;
        end

        % Damped least squares step
        J = jacobianMDH(MDH, q);
        J(4:6,:) = wR * J(4:6,:);   % apply same weight to angular rows

        dq = (J'*J + lambda*eye(n)) \ (J'*e);
        q  = q + dq;
    end
end

function [axis, angle] = rotm2axang_local(R)
% ROTM2AXANG_LOCAL  Convert rotation matrix to axis-angle (robust).

    c = (trace(R)-1)/2;
    c = max(-1, min(1, c));
    angle = acos(c);

    if abs(angle) < 1e-8
        axis = [0;0;0];
        angle = 0;
        return;
    end

    axis = [ R(3,2)-R(2,3);
             R(1,3)-R(3,1);
             R(2,1)-R(1,2) ] / (2*sin(angle));
end
