function workspaceMDH(MDH, qmin, qmax, N)
% WORKSPACEMDH  Approximate end-effector workspace by random sampling.
%
%   workspaceMDH(MDH, qmin, qmax)
%   workspaceMDH(MDH, qmin, qmax, N)
%
%   Inputs:
%     MDH  : n x 5 MDH parameter table
%     qmin : n x 1 vector of joint lower limits
%     qmax : n x 1 vector of joint upper limits
%     N    : (optional) number of random samples (default = 2000)
%
%   Notes:
%     - Workspace is approximated as the set of reachable
%       end-effector positions in the base frame
%     - Sampling is uniform in joint space (not Cartesian space)

    if nargin < 4, N = 2000; end

    n = size(MDH,1);

    qmin = qmin(:);
    qmax = qmax(:);

    if numel(qmin) ~= n || numel(qmax) ~= n
        error('qmin and qmax must be length n.');
    end

    % Optional: fix RNG seed for reproducibility
    % rng(0);

    pts = zeros(N,3);

    for k = 1:N
        q = qmin + (qmax - qmin) .* rand(n,1);
        [~, T_all] = fkineMDH_all(MDH, q);
        pts(k,:) = T_all(1:3,4,end).';
    end

    % Plot workspace
    figure; hold on; grid on; view(3);
    scatter3(pts(:,1), pts(:,2), pts(:,3), 5, '.');
    xlabel('X'); ylabel('Y'); zlabel('Z');
    axis equal;
    title('Approximate End-Effector Workspace (MDH)');
end
