function animateRobotTrajManipMDH(MDH, Q, dt)
% ANIMATEROBOTTRAJMANIPMDH  Animate robot with color mapped to manipulability.
%
%   animateRobotTrajManipMDH(MDH, Q, dt)
%
%   Inputs:
%     MDH : n x 5 MDH parameter table
%     Q   : n x N joint trajectory
%     dt  : animation timestep [s]
%
%   Notes:
%     - Robot color indicates Yoshikawa manipulability index
%     - End-effector path is shown during motion

    [n, N] = size(Q);
    if size(MDH,1) ~= n
        error('Number of joints in Q must match MDH table.');
    end

    % Precompute manipulability
    w = zeros(1,N);
    for k = 1:N
        w(k) = manipulabilityMDH(MDH, Q(:,k));
    end
    wmin = min(w);
    wmax = max(w);
    if wmax == wmin
        wmax = wmin + eps;
    end

    cmap = jet(256);

    % Initial configuration
    q = Q(:,1);
    [~, T_all] = fkineMDH_all(MDH, q);

    % Initial joint positions
    P = zeros(3,n+1);
    P(:,1) = [0;0;0];
    for i = 1:n
        P(:,i+1) = T_all(1:3,4,i);
    end

    % Plot setup
    figure; hold on; grid on; view(3);
    hLinks = plot3(P(1,:), P(2,:), P(3,:), '-o', ...
                   'LineWidth', 2, 'MarkerSize', 6);
    hPath  = plot3(P(1,end), P(2,end), P(3,end), '.', 'MarkerSize', 8);
    xlabel('X'); ylabel('Y'); zlabel('Z');
    axis equal;
    colormap(cmap);
    c = colorbar; ylabel(c, 'w (Yoshikawa)');
    title('Robot Animation Colored by Manipulability');

    % Animation loop
    for k = 1:N
        q = Q(:,k);
        [~, T_all] = fkineMDH_all(MDH, q);

        for i = 1:n
            P(:,i+1) = T_all(1:3,4,i);
        end

        % Update robot links
        set(hLinks, 'XData', P(1,:), ...
                    'YData', P(2,:), ...
                    'ZData', P(3,:));

        % Update end-effector path
        set(hPath, 'XData', [get(hPath,'XData') P(1,end)], ...
                   'YData', [get(hPath,'YData') P(2,end)], ...
                   'ZData', [get(hPath,'ZData') P(3,end)]);

        % Update color based on manipulability
        idx = round(1 + (w(k) - wmin) / (wmax - wmin) * 255);
        idx = max(1, min(256, idx));
        set(hLinks, 'Color', cmap(idx,:));

        drawnow limitrate;
        pause(dt);
    end
end
