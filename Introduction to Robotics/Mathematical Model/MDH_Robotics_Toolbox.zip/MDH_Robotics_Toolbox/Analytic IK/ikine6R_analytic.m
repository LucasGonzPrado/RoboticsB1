function q = ikine6R_analytic(robot, T, config)
% IKINE6R_ANALYTIC  Analytic inverse kinematics for 6R spherical-wrist robot.
%
%   q = ikine6R_analytic(robot, T)
%   q = ikine6R_analytic(robot, T, config)
%
%   Inputs:
%     robot : SerialLink robot (standard DH, spherical wrist)
%     T     : 4x4 homogeneous transform (SE(3))
%     config: (optional) configuration string, e.g.:
%             'lun', 'rdf', 'ruu', etc.
%
%   Output:
%     q : 6x1 joint solution (radians)

    if nargin < 3
        q = robot.ikine6s(T);          % default configuration
    else
        q = robot.ikine6s(T, config);  % specified branch
    end
end
