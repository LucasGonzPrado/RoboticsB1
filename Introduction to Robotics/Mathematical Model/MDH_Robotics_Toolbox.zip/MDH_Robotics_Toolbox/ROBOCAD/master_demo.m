clear; clc; close all;
startup_MDH;

data  = robotData_6R_CAD();
robot = buildRobotMaster(data);

MDH = robot.MDH;
n   = robot.n;

% Home and final configuration (radians)
q0 = zeros(n,1);
q0(2)=2.16510; 
q0(3)=-2.1650;
qf = [ pi; -100/180*pi; 100/180*pi; 0; 0; pi/2 ];   % rad

% Clamp to joint limits (safety)
qf = min(max(qf, robot.qmin), robot.qmax);

%% FK + plot
plotRobotMDH(MDH, q0, true, 0.1);

% FK at home (frame 6 and tool tip)
[~, T_all0] = fkineMDH_all(MDH, q0);
T0_6   = T_all0(:,:,end);
T0_tip = T0_6 * robot.T_tool;

disp('T0_6 (home) =');   disp(T0_6);
disp('T0_tip (home) ='); disp(T0_tip);

%% Jacobian + manipulability
J = jacobianMDH(MDH, q0);
[w,kappa] = manipulabilityMDH(MDH, q0);
fprintf('w = %.4g, kappa = %.4g\n', w, kappa);

%% Workspace
workspaceMDH(MDH, robot.qmin, robot.qmax, 3000);

%% Trajectory
tf = 4; 
dt = 0.05;

[t,Q,Qd,Qdd] = jointTrajQuinticMDH(q0, qf, tf, dt);

% Optional time scaling to respect vel/acc limits (if provided correctly)
if ~isempty(robot.vmax) && ~isempty(robot.amax) ...
        && numel(robot.vmax) == n && numel(robot.amax) == n

    [t2,Q2,Qd2,Qdd2,scale] = timeScaleVelAccMDH(t, Q, robot.vmax, robot.amax);
    fprintf('Time scaling factor: %.3f\n', scale);

    t = t2; Q = Q2; Qd = Qd2; Qdd = Qdd2;
    dt = mean(diff(t));
else
    disp('Time scaling skipped (missing or mismatched vmax/amax).');
end

%% Animation
animateRobotTrajMDH(MDH, Q, dt, false);
animateRobotTrajManipMDH(MDH, Q, dt);

%% Log + dashboard plots
trajLog = logTrajMDH(MDH, t, Q, Qd, Qdd);
plotLogMDH(trajLog);
