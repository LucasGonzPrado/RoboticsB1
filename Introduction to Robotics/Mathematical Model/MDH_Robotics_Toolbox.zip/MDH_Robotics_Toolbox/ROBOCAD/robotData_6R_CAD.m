function data = robotData_6R_CAD()
% ROBOTDATA_6R_CAD  Robot parameters extracted from CAD (6R, spherical wrist).
%
% This file is the SINGLE SOURCE OF TRUTH for your robot dimensions.
% All values are in SI units (meters, radians).
%
% MDH convention used (Craig):
%   MDH(i,:) = [theta0_i, d_i, a_{i-1}, alpha_{i-1}, type_i]
%   type: 0 = revolute, 1 = prismatic
%
% Geometry interpretation (from your CAD measurements):
%   d1 (base->J1)            = 31.00 mm
%   a1 (axis J1 <-> axis J2) = 162.95 mm   <-- corrected
%   a2 (axis J2 <-> axis J3) = 140.50 mm
%   a3 (J3 -> wrist center)  = 194.03 mm
%   tool (wrist center->tip) = 69.00 mm along +Z6

    data = struct();
    data.name = 'My6R_fromCAD';

    % -----------------------------
    % CAD-derived constants [m]
    % -----------------------------
  d1_base = 31.00e-3;     % base -> J1
dz12    = 121.99e-3;    % vertical offset J1 -> J2 (along z1 at home)
dx12    = 105.02e-3;    % horizontal offset J1 -> J2 (along +x1 at home)

a2   = 140.50e-3;       % J2 -> J3 axis distance
a3   = 194.03e-3;       % J3 -> wrist center
tool = 69.00e-3;        % wrist center -> tool tip along +Z6


    % -----------------------------
    % MDH table [theta0 d a alpha type]
    % -----------------------------
    % Notes:
    % - theta0 are set to 0; joint variables q(i) provide motion.
    % - Wrist modeled as spherical with intersecting axes.
    % - Tool offset is handled in data.T_tool, NOT inside MDH.
    %
    % Row meaning:
    %   Joint 1: alpha0 = -pi/2 (J1 ⟂ J2)
    %   Joint 2: alpha1 = 0     (J2 ∥ J3)
    %   Joint 3: alpha2 = 0
    %   Joint 4: alpha3 = -pi/2 (start wrist orientation changes)
    %   Joint 5: alpha4 = +pi/2
    %   Joint 6: alpha5 = 0
    %
data.MDH = [ ...
% theta0   d        a       alpha     type
    0,     d1_base,      0,      0,        0;    % J1 (z1 || z0)
    0,      0,       0,     +pi/2,     0;    % J2: z2 ⟂ z1  (TRY +pi/2 first)
    0,     0,       a2,     0,        0;    % J3: z3 || z2
    0,          0,       a3,    -pi/2,     0;    % J4
    0,          0,       0,     +pi/2,     0;    % J5
    0,          0,       0,      0,        0];   % J6


data.T_12_fixed = [eye(3) [dx12; 0; dz12]; 0 0 0 1]; % meters


    % -----------------------------
    % Joint limits [rad]
    % -----------------------------
    data.qmin = deg2rad([-170; -120; -170; -190; -120; -360]);
    data.qmax = deg2rad([ 170;  120;  170;  190;  120;  360]);

    % -----------------------------
    % Optional dynamic/trajectory limits [rad/s], [rad/s^2]
    % -----------------------------
    data.vmax = deg2rad([120;120;120;180;180;180]);
    data.amax = deg2rad([300;300;300;600;600;600]);

    % -----------------------------
    % Base/tool frames (optional)
    % -----------------------------
    data.T_base = eye(4);

    % Tool: pure translation along +Z6 by tool length.
    % If you have Corke's transl(), you can use it; otherwise use matrix.
    data.T_tool = [eye(3) [0;0;tool]; 0 0 0 1];

end
