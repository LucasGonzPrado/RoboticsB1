%% demo_master_CADrobot.m
% ---------------------------------------------------------
% Master demo for CAD-derived 6R robot (MDH + fixed offset)
%
% Demonstrates:
%   - Correct CAD geometry visualization
%   - FK, Jacobian, manipulability
%   - Workspace
%   - Joint-space trajectory
%   - Animation (normal + manipulability)
%   - Logging and plots
%
% ---------------------------------------------------------

clear; clc; close all;
startup_MDH;

%% Load robot data (single source of truth)
data  = robotData_6R_CAD();
MDH   = data.MDH;

% Fixed CAD offset between J1 and J2
T_12_fixed = data.T_12_fixed;

%% Home configuration
n  = size(MDH,1);
q0 = zeros(n,1);
q0(2)=2.16510; 
q0(3)=-2.1650;

%% ---- 1) CAD-correct visualization ----
disp('Plotting CAD-correct robot geometry...');
plotRobotMDH_CAD(MDH, q0, T_12_fixed, true, 0.08);

%% ---- 2) Forward kinematics ----
[~, T_all] = fkineMDH_all(MDH, q0);
T06 = T_all(:,:,end) * data.T_tool;

disp('End-effector pose at home (pure MDH + tool):');
disp(T06);

%% ---- 3) Jacobian + manipulability ----
J = jacobianMDH(MDH, q0)
[w, kappa] = manipulabilityMDH(MDH, q0);

fprintf('Manipulability w = %.4g\n', w);
fprintf('Condition number κ = %.4g\n', kappa);

%% ---- 4) Workspace ----
disp('Computing workspace...');
workspaceMDH(MDH, data.qmin, data.qmax, 3000);

%% ---- 5) Joint-space trajectory ----
qf = [ pi; pi-2.165; -pi/2; 0; 0; pi/2 ];
tf = 4; 
dt = 0.05;

[t,Q,Qd,Qdd] = jointTrajQuinticMDH(q0, qf, tf, dt);

%% ---- 6) Optional time scaling (velocity / acceleration limits) ----
if isfield(data,'vmax') && isfield(data,'amax')
    [t,Q,Qd,Qdd,scale] = timeScaleVelAccMDH(t,Q,data.vmax,data.amax);
    fprintf('Time scaling factor applied: %.3f\n', scale);
    dt = mean(diff(t));
end

%% ---- 7) Animations ----
disp('Animating trajectory...');
animateRobotTrajMDH(MDH, Q, dt, false);
animateRobotTrajManipMDH(MDH, Q, dt);

%% ---- 8) Logging + dashboard plots ----
log = logTrajMDH(MDH, t, Q, Qd, Qdd);
plotLogMDH(log);

disp('Demo completed successfully ✅');
