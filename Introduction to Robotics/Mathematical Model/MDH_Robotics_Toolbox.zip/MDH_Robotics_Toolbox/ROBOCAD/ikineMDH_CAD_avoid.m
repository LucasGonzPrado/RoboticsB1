function [q, ok, dbg] = ikineMDH_CAD_avoid(MDH, q0, T_target, T_fixed, opts)
% IKINEMDH_CAD_AVOID  DLS IK + singularity avoidance for CAD-aware chain.

    if nargin < 5, opts = struct(); end
    q = q0(:);
    n = size(MDH,1);

    maxIter   = getOpt(opts,'maxIter',250);
    tol       = getOpt(opts,'tol',1e-4);
    lambda0   = getOpt(opts,'lambda0',1e-3);
    lambdaMax = getOpt(opts,'lambdaMax',1e-1);
    kappaHigh = getOpt(opts,'kappaHigh',250);
    alphaNS   = getOpt(opts,'alphaNS',0.05);
    epsGrad   = getOpt(opts,'epsGrad',1e-5);

    dbg.err = zeros(maxIter,1);
    dbg.kappa = zeros(maxIter,1);
    dbg.w = zeros(maxIter,1);
    dbg.lambda = zeros(maxIter,1);

    for k = 1:maxIter
        [~, T_all] = fkineMDH_all_CAD(MDH, q, T_fixed);
        T = T_all(:,:,end);

        e_p = T_target(1:3,4) - T(1:3,4);

        R_err = T(1:3,1:3)' * T_target(1:3,1:3);
        [axis, ang] = rotm2axang_local(R_err);
        e_o = axis * ang;

        e = [e_p; e_o];
        dbg.err(k) = norm(e);

        if dbg.err(k) < tol
            ok = true;
            dbg = trimDbg(dbg,k);
            return;
        end

        J = jacobianMDH_CAD(MDH, q, T_fixed);

        [w, kappa] = manipulabilityFromJ(J);
        dbg.w(k) = w;
        dbg.kappa(k) = kappa;

        if ~isfinite(kappa) || kappa > kappaHigh
            s = min(1, (kappa - kappaHigh)/kappaHigh);
            lambda = lambda0 + s*(lambdaMax - lambda0);
        else
            lambda = lambda0;
        end
        dbg.lambda(k) = lambda;

        H = (J'*J + lambda^2 * eye(n));
        dq_task = H \ (J' * e);

        gradw = gradManipFD(MDH, q, T_fixed, epsGrad);

        Jpinv = H \ J';
        Nproj = eye(n) - Jpinv * J;

        dq_ns = alphaNS * (Nproj * gradw);

        q = q + dq_task + dq_ns;
    end

    ok = false;
end

% ---- helpers ----
function v = getOpt(opts, name, def)
    if isfield(opts,name) && ~isempty(opts.(name)), v = opts.(name); else, v = def; end
end

function dbg = trimDbg(dbg,k)
    f = fieldnames(dbg);
    for i=1:numel(f)
        dbg.(f{i}) = dbg.(f{i})(1:k);
    end
end

function [w,kappa] = manipulabilityFromJ(J)
    JJt = J*J.';
    if rank(JJt) < min(size(JJt))
        w = 0;
    else
        w = sqrt(det(JJt));
    end
    s = svd(J);
    if isempty(s) || min(s)==0
        kappa = Inf;
    else
        kappa = max(s)/min(s);
    end
end

function g = gradManipFD(MDH, q, T_fixed, eps)
    n = numel(q);
    g = zeros(n,1);

    J0 = jacobianMDH_CAD(MDH, q, T_fixed);
    [w0, ~] = manipulabilityFromJ(J0);

    for i=1:n
        qp = q; qm = q;
        qp(i) = qp(i) + eps;
        qm(i) = qm(i) - eps;

        Jp = jacobianMDH_CAD(MDH, qp, T_fixed);
        Jm = jacobianMDH_CAD(MDH, qm, T_fixed);

        [wp, ~] = manipulabilityFromJ(Jp);
        [wm, ~] = manipulabilityFromJ(Jm);

        g(i) = (wp - wm) / (2*eps);
    end

    if ~isfinite(w0)
        g(:) = 0;
    end
end

function [axis, angle] = rotm2axang_local(R)
    angle = acos(max(-1,min(1,(trace(R)-1)/2)));
    if abs(angle) < 1e-8
        axis = [0;0;0]; angle = 0; return;
    end
    axis = [ R(3,2)-R(2,3);
             R(1,3)-R(3,1);
             R(2,1)-R(1,2) ] / (2*sin(angle));
end
